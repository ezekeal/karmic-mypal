<?php
/**
 * {license_notice}
 *
 * @category    Magento
 * @package     Magento_Exception
 * @copyright   {copyright}
 * @license     {license_link}
 */

class Magento_Exception extends Exception
{

}
